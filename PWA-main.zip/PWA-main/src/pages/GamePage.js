import React from 'react';

function GamePage() {
  return (
    <div>
      <h1>Wild Horizon Safari Game</h1>
      {/* Add game components/logic here */}
    </div>
  );
}

export default GamePage;
