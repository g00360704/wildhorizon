// src/views/GameInfo.js
import React from 'react';

function GameInfo() {
    return (
        <div>
            <h2>Game Information</h2>
            {/* Game story, characters, screenshots can be added here. */}
        </div>
    );
}

export default GameInfo;
