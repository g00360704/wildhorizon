// src/views/Store.js
import React from 'react';

function Store() {
    return (
        <div>
            <h2>Store</h2>
            {/* Products can be listed here. */}
        </div>
    );
}

export default Store;
